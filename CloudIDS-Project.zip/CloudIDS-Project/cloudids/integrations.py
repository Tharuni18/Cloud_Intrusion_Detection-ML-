"""Normalize cloud-native security findings into a minimal, privacy-conscious record.

Provider findings remain distinct from ML flow predictions. This module accepts the
common AWS Security Hub/GuardDuty, Azure Defender, and Google SCC event envelopes; a
trusted provider relay should authenticate to the local API and forward the envelope.
Raw provider payloads are deliberately not persisted.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


def _text(value: Any, limit: int = 300) -> str:
    return str(value or "")[:limit]


def _severity(value: Any) -> str:
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        number = float(value)
        if number <= 10:
            return "critical" if number >= 9 else "high" if number >= 7 else "medium" if number >= 4 else "low"
        return "critical" if number >= 90 else "high" if number >= 70 else "medium" if number >= 40 else "low"
    raw = _text(value).strip().lower()
    if raw.startswith("severity_"):
        raw = raw.removeprefix("severity_")
    if raw.isdigit():
        number = int(raw)
        return "critical" if number >= 90 else "high" if number >= 70 else "medium" if number >= 40 else "low"
    if raw in {"critical", "high", "medium", "low", "informational", "info"}:
        return "info" if raw in {"informational", "info"} else raw
    return "unknown"


def _aws(payload: dict) -> list[dict]:
    detail = payload.get("detail", payload)
    if not isinstance(detail, dict):
        return []
    findings = detail.get("findings")
    if not isinstance(findings, list):
        findings = [detail]
    out = []
    for f in findings:
        if not isinstance(f, dict):
            continue
        sev = f.get("Severity", f.get("severity", {}))
        sev = sev.get("Label", sev.get("Normalized", "unknown")) if isinstance(sev, dict) else sev
        resources = f.get("Resources", f.get("resources", []))
        resource = ""
        if isinstance(resources, list) and resources and isinstance(resources[0], dict):
            resource = resources[0].get("Id", resources[0].get("name", ""))
        if not resource and isinstance(f.get("resource"), dict):
            resource_data = f["resource"]
            instance = resource_data.get("instanceDetails", {})
            resource = (resource_data.get("id") or resource_data.get("resourceId") or
                        (instance.get("instanceId") if isinstance(instance, dict) else ""))
        out.append({"finding_id": f.get("Id", f.get("id", payload.get("id", ""))),
                    "title": f.get("Title", f.get("type", f.get("Types", "AWS security finding"))),
                    "severity": _severity(sev), "resource": resource,
                    "category": f.get("Types", f.get("type", "security-finding")),
                    "occurred_at": f.get("CreatedAt", f.get("createdAt", f.get("updatedAt", payload.get("time", "")))),
                    "description": f.get("Description", f.get("description", ""))})
    return out


def _azure(payload: dict) -> list[dict]:
    data = payload.get("data", payload)
    if not isinstance(data, dict):
        return []
    essentials = data.get("essentials", data)
    if not isinstance(essentials, dict):
        return []
    return [{"finding_id": essentials.get("systemAlertId", payload.get("id", "")),
             "title": essentials.get("alertDisplayName", data.get("title", "Azure security alert")),
             "severity": _severity(essentials.get("severity", data.get("severity"))),
             "resource": essentials.get("compromisedEntity", ""),
             "category": essentials.get("alertType", data.get("category", "security-alert")),
             "occurred_at": essentials.get("startTimeUtc", payload.get("eventTime", "")),
             "description": essentials.get("description", data.get("description", ""))}]


def _gcp(payload: dict) -> list[dict]:
    finding = payload.get("finding", payload.get("data", payload))
    if not isinstance(finding, dict):
        return []
    resource = finding.get("resource", {})
    if isinstance(resource, dict):
        resource = resource.get("name", resource.get("displayName", ""))
    return [{"finding_id": finding.get("name", finding.get("id", payload.get("id", ""))),
             "title": finding.get("category", finding.get("title", "Google Cloud security finding")),
             "severity": _severity(finding.get("severity", "unknown")),
             "resource": resource,
             "category": finding.get("category", "security-finding"),
             "occurred_at": finding.get("eventTime", finding.get("createTime", payload.get("time", ""))),
             "description": finding.get("description", "")}]


def normalize_findings(provider: str, payload: Any) -> list[dict]:
    """Return bounded normalized records for AWS, Azure, or GCP finding events."""
    provider = _text(provider, 20).strip().lower()
    if provider not in {"aws", "azure", "gcp"}:
        raise ValueError("provider must be aws, azure, or gcp")
    if not isinstance(payload, dict):
        raise ValueError("provider payload must be a JSON object")
    records = {"aws": _aws, "azure": _azure, "gcp": _gcp}[provider](payload)
    if not records:
        raise ValueError("payload contains no supported provider finding")
    now = datetime.now(timezone.utc).isoformat(timespec="milliseconds")
    normalized = []
    for item in records[:100]:
        finding_id = _text(item.get("finding_id"), 300).strip()
        title = _text(item.get("title"), 300).strip()
        if not finding_id or not title:
            raise ValueError("each provider finding needs an ID and title")
        normalized.append({"finding_id": finding_id, "title": title,
                           "severity": _severity(item.get("severity")),
                           "resource": _text(item.get("resource"), 300),
                           "category": _text(item.get("category"), 160),
                           "occurred_at": _text(item.get("occurred_at"), 80) or now,
                           "description": _text(item.get("description"), 1000)})
    return normalized
