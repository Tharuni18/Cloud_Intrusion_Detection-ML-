# Cloud Intrusion Detection - Experiment Report

*Dataset:* `unsw-nb15`  |  train/val/test = 44,576 / 11,145 / 94,835  |  features = 68

*Backends:* supervised boosting = **xgboost**, autoencoder = **sklearn**, clustering = **sklearn MiniBatchKMeans (8 clusters)**.

*Operating point:* target false-positive rate = 1.00% on benign validation traffic; evaluation profile = full.

*Test protocol:* official supplied test partition, sampled with at most 40,000 rows per class; attack prevalence = 57.8%. Precision/PR-AUC depend on this test-set mix; false-alarm rates can shift on production traffic.

## 1. Closed-world results (all attack types seen in training)

| detector | precision | precision_ci_low | precision_ci_high | recall | recall_ci_low | recall_ci_high | f1 | fpr | fpr_ci_low | fpr_ci_high | accuracy | balanced_accuracy | mcc | tp | fp | tn | fn | pr_auc | roc_auc | macro_f1_multiclass |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Rules | 0.3658 | 0.3404 | 0.3920 | 0.0089 | 0.0081 | 0.0097 | 0.0174 | 0.0211 | 0.0198 | 0.0226 | 0.4180 | 0.4939 | -0.0514 | 488 | 846 | 39154 | 54347 | 0.5763 | 0.4939 | nan |
| RandomForest | 0.9954 | 0.9947 | 0.9961 | 0.6414 | 0.6374 | 0.6454 | 0.7801 | 0.0040 | 0.0035 | 0.0047 | 0.7909 | 0.8187 | 0.6510 | 35171 | 162 | 39838 | 19664 | 0.9815 | 0.9759 | 0.5507 |
| XGBoost | 0.9947 | 0.9939 | 0.9954 | 0.6474 | 0.6434 | 0.6514 | 0.7843 | 0.0047 | 0.0041 | 0.0054 | 0.7941 | 0.8213 | 0.6551 | 35501 | 189 | 39811 | 19334 | 0.9807 | 0.9752 | 0.5579 |
| Autoencoder | 0.9801 | 0.9778 | 0.9822 | 0.2722 | 0.2685 | 0.2760 | 0.4261 | 0.0076 | 0.0068 | 0.0085 | 0.5760 | 0.6323 | 0.3560 | 14928 | 303 | 39697 | 39907 | 0.8206 | 0.7048 | nan |
| Benign-KMeans | 0.9854 | 0.9830 | 0.9875 | 0.1946 | 0.1913 | 0.1980 | 0.3251 | 0.0040 | 0.0034 | 0.0046 | 0.5327 | 0.5953 | 0.2961 | 10673 | 158 | 39842 | 44162 | 0.7627 | 0.6662 | nan |
| Hybrid-OR | 0.9868 | 0.9856 | 0.9879 | 0.6590 | 0.6550 | 0.6629 | 0.7902 | 0.0121 | 0.0111 | 0.0132 | 0.7977 | 0.8234 | 0.6561 | 36134 | 484 | 39516 | 18701 | 0.8911 | 0.8097 | nan |
| Hybrid-Stacked | 0.9863 | 0.9851 | 0.9874 | 0.6933 | 0.6894 | 0.6971 | 0.8142 | 0.0132 | 0.0121 | 0.0143 | 0.8171 | 0.8400 | 0.6838 | 38015 | 527 | 39473 | 16820 | 0.9797 | 0.9739 | nan |

![PR](figures/pr_curves.png)

Per-class detection rate (benign column = true-negative rate):

| item | Rules | RandomForest | XGBoost | Autoencoder | Benign-KMeans | Hybrid-OR | Hybrid-Stacked |
|---|---|---|---|---|---|---|---|
| analysis | 0.0000 | 0.7153 | 0.7090 | 0.5414 | 0.7272 | 0.7335 | 0.7300 |
| backdoor | 0.0007 | 0.9066 | 0.9095 | 0.6003 | 0.7936 | 0.9464 | 0.9631 |
| benign | 0.9788 | 0.9960 | 0.9953 | 0.9924 | 0.9960 | 0.9879 | 0.9868 |
| dos | 0.0044 | 0.7927 | 0.8112 | 0.3969 | 0.3244 | 0.8422 | 0.8859 |
| exploits | 0.0032 | 0.8649 | 0.8701 | 0.3198 | 0.1162 | 0.8792 | 0.9151 |
| fuzzers | 0.0234 | 0.0919 | 0.0930 | 0.0656 | 0.0711 | 0.1032 | 0.1434 |
| generic | 0.0041 | 0.9642 | 0.9584 | 0.8613 | 0.6740 | 0.9647 | 0.9779 |
| reconnaissance | 0.0004 | 0.9205 | 0.9479 | 0.1271 | 0.1541 | 0.9566 | 0.9747 |
| shellcode | 0.0101 | 0.5848 | 0.5600 | 0.0027 | 0.0000 | 0.5619 | 0.7113 |
| worms | 0.0315 | 0.8661 | 0.8425 | 0.1732 | 0.0000 | 0.8504 | 0.8819 |

## 2. Zero-day results (attack class removed from training)

Recall on the **unseen** class (each row = a separate retraining):

| holdout | Autoencoder | Benign-KMeans | Hybrid-OR | Hybrid-Stacked | RandomForest | Rules | XGBoost |
|---|---|---|---|---|---|---|---|
| analysis | 0.5414 | 0.7272 | 0.7335 | 0.7286 | 0.6978 | 0.0000 | 0.6992 |
| backdoor | 0.6003 | 0.7936 | 0.9450 | 0.9399 | 0.8726 | 0.0007 | 0.9080 |
| dos | 0.3969 | 0.3244 | 0.8386 | 0.8796 | 0.7699 | 0.0044 | 0.7908 |
| exploits | 0.3198 | 0.1162 | 0.8305 | 0.8590 | 0.7281 | 0.0032 | 0.8039 |
| fuzzers | 0.0656 | 0.0711 | 0.1000 | 0.1203 | 0.0905 | 0.0234 | 0.0918 |
| generic | 0.8613 | 0.6740 | 0.9486 | 0.6810 | 0.1543 | 0.0041 | 0.1873 |
| reconnaissance | 0.1271 | 0.1541 | 0.5785 | 0.6220 | 0.4273 | 0.0004 | 0.5657 |
| shellcode | 0.0027 | 0.0000 | 0.2722 | 0.5399 | 0.2951 | 0.0101 | 0.2704 |
| worms | 0.1732 | 0.0000 | 0.8425 | 0.8976 | 0.8583 | 0.0315 | 0.8346 |

![zero-day](figures/zero_day_recall.png)

Mean false-positive rate across those runs:

| detector | mean_fpr |
|---|---|
| Autoencoder | 0.0076 |
| Benign-KMeans | 0.0040 |
| Hybrid-OR | 0.0125 |
| Hybrid-Stacked | 0.0140 |
| RandomForest | 0.0036 |
| Rules | 0.0211 |
| XGBoost | 0.0052 |

Recall on the *known* attack classes in the same runs:

| holdout | Autoencoder | Benign-KMeans | Hybrid-OR | Hybrid-Stacked | RandomForest | Rules | XGBoost |
|---|---|---|---|---|---|---|---|
| analysis | 0.2650 | 0.1804 | 0.6564 | 0.6867 | 0.6303 | 0.0091 | 0.6428 |
| backdoor | 0.2638 | 0.1792 | 0.6584 | 0.6858 | 0.6311 | 0.0091 | 0.6482 |
| dos | 0.2634 | 0.1854 | 0.6489 | 0.6788 | 0.6331 | 0.0092 | 0.6365 |
| exploits | 0.2456 | 0.2385 | 0.5366 | 0.5812 | 0.5075 | 0.0121 | 0.5214 |
| fuzzers | 0.3572 | 0.2455 | 0.9216 | 0.9410 | 0.8860 | 0.0029 | 0.9164 |
| generic | 0.2239 | 0.1553 | 0.6280 | 0.6749 | 0.6097 | 0.0093 | 0.6119 |
| reconnaissance | 0.2947 | 0.2009 | 0.6178 | 0.6512 | 0.5936 | 0.0102 | 0.6055 |
| shellcode | 0.2777 | 0.1986 | 0.6704 | 0.6967 | 0.6409 | 0.0089 | 0.6603 |
| worms | 0.2725 | 0.1951 | 0.6663 | 0.7000 | 0.6273 | 0.0088 | 0.6553 |

## 3. Latency

| detector | batch_flows_per_sec | single_flow_ms |
|---|---|---|
| Rules | 2053177.3010 | 0.6380 |
| RandomForest | 2538.9040 | 80.1590 |
| XGBoost | 10666.5810 | 7.3900 |
| Autoencoder | 86437.1470 | 1.8530 |
| Benign-KMeans | 226580.1130 | 1.1780 |
| Hybrid-OR | 6484.2750 | 18.0640 |
| Hybrid-Stacked | 14860.3200 | 7.0650 |

## 4. Explainability

Top features by permutation importance:

| item | pr_auc_drop |
|---|---|
| sttl | 0.1763 |
| ct_dst_src_ltm | 0.0390 |
| dbytes | 0.0027 |
| smean | 0.0025 |
| proto_other | 0.0014 |
| dmean | 0.0013 |
| sbytes | 0.0012 |
| dttl | 0.0008 |
| ct_dst_sport_ltm | 0.0008 |
| ct_dst_ltm | 0.0007 |

![imp](figures/feature_importance.png)

![ae](figures/ae_error_distribution.png)
